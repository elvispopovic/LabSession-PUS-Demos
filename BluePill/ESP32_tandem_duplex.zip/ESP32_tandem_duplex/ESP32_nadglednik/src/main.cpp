#include <Arduino.h>
#include <mutex>

/*  for UART1 we can not use pin 9 and 10 (flash), and also
    we can not use 1 and 3 (Serial)
    avoid to use 2 (LED pin) and 16 and 17 (Serial 2)
*/

#define UART1_RX 18
#define UART1_TX 19
#define LED_PIN 2


std::mutex mtx_message; 

HardwareSerial SerialPort(1); // UART1

String message, message1;

unsigned long LED_time;

void onReceive()
{
  message = Serial.readStringUntil('\n');
}

void OnReceive1()
{
  std::lock_guard<std::mutex> lock(mtx_message);
  digitalWrite(LED_PIN, HIGH);
  LED_time = millis();
  while(SerialPort.available()>0)
  {
    message1 += SerialPort.readStringUntil('\n');
  }
}

void setup() 
{
  Serial.begin(115200);
  Serial.onReceive(onReceive);
  SerialPort.begin(9600, SERIAL_8N1, UART1_RX, UART1_TX); //UART1 redirection to pins 18 and 19
  SerialPort.onReceive(OnReceive1);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);
  LED_time = millis();
  Serial.println("ESP32 program started.");
  SerialPort.println("Start");
}

unsigned long testTime = millis();

void loop() 
{
  /* send UART message by timer */
  if(millis()-testTime > 3000)
  {
    SerialPort.println("Time test");
    testTime = millis();
    delay(30);
  }

  /* send UART mesage received from Serial port */
  if(!message.isEmpty())
  {
    SerialPort.println(message);
    message.clear();
    delay(30);
  }
  delay(1);
  std::lock_guard<std::mutex> lock(mtx_message);
  if(millis()-LED_time > 25)
    digitalWrite(LED_PIN, LOW);
  if(!message1.isEmpty())
  {
    Serial.println(message1);
    message1.clear();
  }
}