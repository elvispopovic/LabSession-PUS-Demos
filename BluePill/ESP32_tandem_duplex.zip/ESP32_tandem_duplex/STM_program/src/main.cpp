#include <Arduino.h>

#define SERIAL1_RX PA10
#define SERIAL1_TX PA9
#define LED_PIN PC13

HardwareSerial Serial1(SERIAL1_RX, SERIAL1_TX); //rx, tx, no Serial1 on Mac

String message;

void setup() 
{
  Serial1.begin(9600); //doesn't work in Code, but do in Arduino IDE
  if(Serial1)
    Serial1.println("Program started.");
  pinMode(LED_PIN, OUTPUT);
}

char buffer[64];

void loop() 
{
  static byte toggle = 0;
  static int counter = 0;
  int size;

  if(Serial1.available() > 0)
  {
    message = Serial1.readStringUntil('\n');
    Serial1.println(message);
  } 

  delay(30); //obligate after \n

  Serial1.print(counter++);
  if(toggle)
  {
    digitalWrite(LED_PIN, HIGH);
    Serial1.println(": LED ON");
  }
  else
  {
    digitalWrite(LED_PIN, LOW);
    Serial1.println(": LED OFF");
  }
  toggle = 1-toggle;

  delay(1000);
}