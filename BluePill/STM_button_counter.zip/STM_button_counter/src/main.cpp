#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <deque>

#define LED_PIN PC13
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define BUTTON_PIN PB12

Adafruit_SSD1306 screen(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1); //ESP32
std::deque<String> screenRows;
void screenInit();
void screenClear();
void screenTest();
void printRow(String text);

volatile byte toggle, lastToggle;
volatile bool buttonPressed;
unsigned long intTime, lastIntTime;
void buttonPressedISR();

void setup() 
{
  pinMode(LED_PIN, OUTPUT);
  buttonPressed = false;
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  lastToggle = 1;
  toggle = 0;  
  lastIntTime = 0;

  screenInit();
  screenTest();

  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN),buttonPressedISR,CHANGE);  
  delay(3000);
  screenClear();
  printRow("Press the button...");
}

unsigned long counterTimer = millis();

void loop() 
{
  static int rowCount = 0;
  static int counter = 0;
  unsigned long t = millis();

  if((t-counterTimer > 1000))
  {
    String s(counter++);
    if(counter > 99)
      counter = 0;
    int16_t x,y;
    uint16_t w,h;
    screen.getTextBounds(s,0,0,&x,&y,&w,&h);
    screen.setCursor(screen.width()-3-w,3);
    screen.fillRect(screen.width()-3-w,3,w,h,BLACK);
    screen.print(s);
    counterTimer = t;
    screen.display();
  }

  if(buttonPressed && t-lastIntTime>20)
  {
    lastIntTime = t;
    if(digitalRead(BUTTON_PIN) == LOW && lastToggle == HIGH)
    {
      toggle = !toggle;
      lastToggle = LOW;
      String s(rowCount++);
      s+=": ";
      if(toggle)
      {
        digitalWrite(LED_PIN, LOW);
        s+="LED ON";
      }
      else
      {
        digitalWrite(LED_PIN, HIGH);
        s+="LED OFF";
      }
      printRow(s);
    }
    else if(digitalRead(BUTTON_PIN) == HIGH && lastToggle == LOW)
      lastToggle = HIGH;
    lastIntTime = t;
    buttonPressed = false;
  }
  delay(1);
}

void buttonPressedISR()
{
  buttonPressed = true;
}

void printRow(String text)
{
  int i;
  std::deque<String>::iterator it;
  if(screenRows.size()>6)
    screenRows.pop_front();
  screenRows.push_back(text.substring(0,20));
  screenClear();
  for(it=screenRows.begin(), i=3; it!=screenRows.end(); ++it, i+=8)
  {
    screen.setCursor(3,i);
    screen.print(*it);
  }
  screen.display();
}

void screenInit()
{
  screen.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  screen.clearDisplay();
  screen.drawRect(0,0,screen.width()-1,screen.height()-1, WHITE);
  screen.setTextSize(0);
  screen.setTextWrap(false);
  screen.setTextColor(WHITE);
}

void screenClear()
{
  screen.clearDisplay();
  screen.drawRect(0,0,screen.width()-1,screen.height()-1, WHITE);
  screen.display();
}

void screenTest()
{
  screenClear();
  screen.drawCircle(screen.width()/2, screen.height()/2-1,(screen.height()-3)/2,WHITE);
  screen.drawLine(3,screen.height()/2, screen.width()-3, screen.height()/2, WHITE);
  screen.drawLine(screen.width()/2, 3, screen.width()/2, screen.height()-3, WHITE);
  screen.setCursor(3,3);
  screen.println("Test");
  screen.display();
}